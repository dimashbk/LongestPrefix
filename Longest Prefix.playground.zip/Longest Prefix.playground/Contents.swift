
class Solution {
    func longestCommonPrefix(_ strs: [String]) -> String {
        var longestPrefix: String = ""
          if strs[0] == ""
    {
        return ""
    }
    
    
    
            
    for i in 1...strs[0].count
    {
        var count = 0
        let index = strs[0].index(strs[0].startIndex, offsetBy: i)
        var temp = strs[0][..<index]
        var sttemp = String(temp)
      
     
        for j in 0...strs.count - 1
        {
            
        
            if strs[j].hasPrefix(sttemp)
            {
                count += 1
                
            }
            
            
        }
        print(count)
        if count == strs.count
        {
            longestPrefix = sttemp
            
        }
        else if count < strs.count
        {
            return longestPrefix
        }
        
    
    }
    
   return longestPrefix
    
}
    
}
